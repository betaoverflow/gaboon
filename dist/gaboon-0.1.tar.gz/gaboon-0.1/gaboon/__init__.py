gaboon = '''
Code minimum and efficient using Gaboon's implementation of common algorithms!
   _____       _                       
  / ____|     | |                      
 | |  __  __ _| |__   ___   ___  _ __  
 | | |_ |/ _` | '_ \ / _ \ / _ \| '_ \ 
 | |__| | (_| | |_) | (_) | (_) | | | |
  \_____|\__,_|_.__/ \___/ \___/|_| |_|
                                       
                                       
'''

print(gaboon)
